package com.mautini.assistant.demo.exception;

public class ConverseException extends Exception {

    public ConverseException(String message, Throwable cause) {
        super(message, cause);
    }
}

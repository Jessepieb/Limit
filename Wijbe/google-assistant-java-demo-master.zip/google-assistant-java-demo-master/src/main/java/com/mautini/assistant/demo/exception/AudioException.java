package com.mautini.assistant.demo.exception;

public class AudioException extends Exception {

    public AudioException(String message, Throwable cause) {
        super(message, cause);
    }
}

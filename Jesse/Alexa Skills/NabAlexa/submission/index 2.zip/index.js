'use strict';

const Alexa = require('ask-sdk');
const aws = require('aws-sdk');
const rp = require('request-promise');
var nodemailer = require('nodemailer');

aws.config.update({
  accessKeyId: 'AKIAIOXQBBAACX4ITGFA', 
  secretAccessKey: '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'
});
var sqs = new aws.SQS({region:'us-west-2'}); 
var parseString = require('xml2js').parseString;
var queueURL = "https://sqs.us-west-2.amazonaws.com/568982321218/Alexa_Queue"

// var xmlRequest = new XMLHttpRequest();
// var xml = xmlRequest.responseXML;

// access_key = "AKIAIOXQBBAACX4ITGFA";
// access_secret = "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";
// region ="us-west-2";
// queue_url = "https://sqs.us-west-2.amazonaws.com/568982321218/NabAlexa_Function";

// aws.config.update({region: 'us-west-2'});
// var sqs = new aws.SQS({apiVersion: '2012-11-05'})
// var queueURL = 'https://sqs.us-west-2.amazonaws.com/568982321218/NabAlexa_Function';
// var sqs = new aws.SQS({"accessKeyId":"AKIAIOXQBBAACX4ITGFA", "secretAccessKey": "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", "region": "Oregon"})

const LaunchRequestHandler = {
   canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;
      return request.type === 'LaunchRequest';
         // || request.type === 'IntentRequest'
         //   && request.intent.name === 'MainMenuIntent';
   },
   handle(handlerInput) {
         console.log('LaunchRequest');
         let attributes = handlerInput.attributesManager.getSessionAttributes();
         // attributes = {}; // Clear all persistant attributes.

         let speech = 'Hello test';
         return handlerInput.responseBuilder
            .speak(speech)
            .reprompt(speech)
            .getResponse();
   }
};


// ===================================================================
// ---------------------- SINGLE ACTION INTENTS ----------------------
// ===================================================================
const TurnOnLampIntent = {
   canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return request.type === 'IntentRequest'
         && request.intent.name === 'TurnOnLampIntent';
   },
   handle(handlerInput) {
      console.log('TurnOnLampIntent');
      //let attributes = handlerInput.attributesManager.getSessionAttributes();

      turnOnLamp();
      let speech = 'Here you go.';
      let repromptSpeech = 'Here you go.';
      //setLastSpeech(handlerInput, speech, repromptSpeech);

      return handlerInput.responseBuilder
         .speak(speech)
         .reprompt(repromptSpeech)
         .getResponse();
   },
};

const TurnOffLampIntent = {
   canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return request.type === 'IntentRequest'
         && request.intent.name === 'TurnOffLampIntent';
   },
   handle(handlerInput) {
      console.log('TurnOffLampIntent');
      //let attributes = handlerInput.attributesManager.getSessionAttributes();

      turnOffLamp();
      let speech = 'Turning off your lamp.';
      let repromptSpeech = 'Turning off your lamp.';
      //setLastSpeech(handlerInput, speech, repromptSpeech);

      return handlerInput.responseBuilder
         .speak(speech)
         .reprompt(repromptSpeech)
         .getResponse();
   },
};

const TurnUpHeatIntent = {
   canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return request.type === 'IntentRequest'
         && request.intent.name === 'TurnUpHeatIntent';
   },
   handle(handlerInput) {
      console.log('TurnUpHeatIntent');
      //let attributes = handlerInput.attributesManager.getSessionAttributes();

      turnUpHeat();
      let speech = 'Turning up the heat.';
      let repromptSpeech = 'Turning up the heat.';
      //setLastSpeech(handlerInput, speech, repromptSpeech);

      return handlerInput.responseBuilder
         .speak(speech)
         .reprompt(repromptSpeech)
         .getResponse();
   },
};

const TurnOnCoolingIntent = {
   canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return request.type === 'IntentRequest'
         && request.intent.name === 'TurnOnCoolingIntent';
   },
   handle(handlerInput) {
      console.log('TurnOnCoolingIntent');
      //let attributes = handlerInput.attributesManager.getSessionAttributes();

      turnOnCooling();
      let speech = 'Turning on the cooling.';
      let repromptSpeech = 'Turning on the cooling.';
      //setLastSpeech(handlerInput, speech, repromptSpeech);

      return handlerInput.responseBuilder
         .speak(speech)
         .reprompt(repromptSpeech)
         .getResponse();
   },
};

// ASK CURRENT TEMPERATURE
const CurrentTemperatureIntent = {
   canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return request.type === 'IntentRequest'
         && request.intent.name === 'CurrentTemperatureIntent';
   },
   async handle(handlerInput) {
      console.log('CurrentTemperatureIntent');
      //let attributes = handlerInput.attributesManager.getSessionAttributes();

      //---------------
      var params = {
         QueueUrl: queueURL,
         MaxNumberOfMessages: 1
      };

      return await getCurrentTemp()
         .then(async function(result) {
            let speech = result;

            console.log('result from function: ', result);
            return handlerInput.responseBuilder
               .speak(speech)
               .reprompt(speech)
               .getResponse();
         });
      // let speech = tempSpeech;
      // let repromptSpeech = tempSpeech;
      // console.log('typeof: ' + typeof speech);

      

      //---------------
      //let tempSpeech = getCurrentTemp();
      // let speech = tempSpeech;
      // let repromptSpeech = tempSpeech;



      // return getCurrentTemp()
      //    .then(function(result) {
      //       let tempSpeech = result;
      //       console.log('result ' + result);
      //       let speech = tempSpeech;
      //       let repromptSpeech = tempSpeech;
      //       //setLastSpeech(handlerInput, speech, repromptSpeech);

            
      //    })
      // let tempSpeech = getCurrentTemp();
      
   },
};

// ===================================================================
// ---------------------- EVENT ACTION INTENTS -----------------------
// ===================================================================
const IAmHomeIntent = {
   canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return request.type === 'IntentRequest'
         && request.intent.name === 'IAmHomeIntent';
   },
   handle(handlerInput) {
      console.log('IAmHomeIntent');
      //let attributes = handlerInput.attributesManager.getSessionAttributes();

      turnOnLamp();
      turnUpHeat();
      sendTonightMovies();
      let speech = 'Welcome home. I\'m turning on your lights and heat. Check your phone for movies playing tonight.';
      let repromptSpeech = 'Welcome home. I\'m turning on your lights and heat. Check your phone for movies playing tonight.';
      //setLastSpeech(handlerInput, speech, repromptSpeech);

      return handlerInput.responseBuilder
         .speak(speech)
         .reprompt(repromptSpeech)
         .getResponse();
   },
};

// I'M GOING TO BED (turn off everything, including cooling/heating)
// WATCHING A MOVIE (dimmed lighting, in rest of house lights are off)
// READING A BOOK (relexing music in background, good lighting)
// I'M LEAVING (turn off everything, including cooling/heating)



// const SetAlarmIntent = {
//   canHandle(handlerInput) {
//     const request = handlerInput.requestEnvelope.request;

//     return request.type === 'IntentRequest'
//         && request.intent.name === 'SetAlarmIntent';
//   },
//   handle(handlerInput) {
//     console.log('SetAlarmIntent');
//     const request = handlerInput.requestEnvelope.request;
//     const intentSlots = request.intent.slots;
//     //let attributes = handlerInput.attributesManager.getSessionAttributes();
    
//     var time = intentSlots.time.value;
    
//     let speech = 'Setting an alarm for ' + time; //+ time;
//     let repromptSpeech = 'Setting an alarm for ' + time; //+ time;
//     //setLastSpeech(handlerInput, speech, repromptSpeech);

//     return handlerInput.responseBuilder
//       .speak(speech)
//       .reprompt(repromptSpeech)
//       .getResponse();
//   },
// };

// ===================================================================
// ------------------------- HELPER INTENTS --------------------------
// ===================================================================
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
          && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
            || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
      const speech = 'Thanks for using home control. See you next time!';

      return handlerInput.responseBuilder
        .speak(speech)
        .getResponse();
    },
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
      return handlerInput.requestEnvelope.request.type === 'IntentRequest'
        && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
      console.log('HelpIntent');
      let speech = 'There is a problem with the Help intent';
      
      return handlerInput.responseBuilder
        .speak(speech)
        .reprompt(speech)
        .getResponse();
    },
};

const UnhandledIntent = {
    canHandle(handlerInput) {
      return handlerInput.requestEnvelope.request.type === 'IntentRequest'
        && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
      console.log('UnhandledIntent');
      let speech = 'Something is wrong. You are in the unhandled intent right now...';
      
      return handlerInput.responseBuilder
        .speak(speech)
        .reprompt(speech)
        .getResponse();
    },
};

const SessionEndedHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);
    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    const request = handlerInput.requestEnvelope.request;
    console.log(`Error handled: ${error.message}`);
    console.log(`Original request was ${JSON.stringify(request, null, 2)}\n`);

    return handlerInput.responseBuilder
      .speak('Error in index.js')
      .reprompt('Error in index.js')
      .getResponse();
  },
};

// EXPORT HANDLER FUNCTION
const skillBuilder = Alexa.SkillBuilders.standard();
exports.handler = skillBuilder
   .addRequestHandlers(LaunchRequestHandler,
                     TurnOnLampIntent,
                     TurnOffLampIntent,
                     TurnUpHeatIntent,
                     TurnOnCoolingIntent,
                     CurrentTemperatureIntent,
                     IAmHomeIntent,
                     //SetAlarmIntent,
                     CancelAndStopIntentHandler,
                     HelpIntentHandler,
                     UnhandledIntent,
                     SessionEndedHandler)
   .addErrorHandlers(ErrorHandler)
   //.withTableName('2018_Democracy_Live')
   //.withAutoCreateTable(true)
   .lambda();

// ===================================================================
// ----------------------- HELPER FUNCTIONS --------------------------
// ===================================================================
function turnOnLamp() {
   var msg = "lamp_on";

   var sqsParams = {
      MessageBody: JSON.stringify(msg),
      QueueUrl: 'https://sqs.us-west-2.amazonaws.com/568982321218/Alexa_Queue'
   };

   sqs.sendMessage(sqsParams, function(err, data) {
      if (err) {
         console.log('ERR', err);
      }
      console.log(data);
   });
}

function turnOffLamp() {
   var msg = "lamp_off";

   var sqsParams = {
      MessageBody: JSON.stringify(msg),
      QueueUrl: 'https://sqs.us-west-2.amazonaws.com/568982321218/Alexa_Queue'
   };

   sqs.sendMessage(sqsParams, function(err, data) {
      if (err) {
         console.log('ERR', err);
      }

      console.log(data);
   });
}

function turnUpHeat() {
   var msg = "heat_up";

   var sqsParams = {
      MessageBody: JSON.stringify(msg),
      QueueUrl: 'https://sqs.us-west-2.amazonaws.com/568982321218/Alexa_Queue'
   };

   sqs.sendMessage(sqsParams, function(err, data) {
      if (err) {
         console.log('ERR', err);
      }

   console.log(data);
   });
}

function turnOnCooling() {
   var msg = "cooling_on";

   var sqsParams = {
      MessageBody: JSON.stringify(msg),
      QueueUrl: 'https://sqs.us-west-2.amazonaws.com/568982321218/Alexa_Queue'
   };

   sqs.sendMessage(sqsParams, function(err, data) {
      if (err) {
         console.log('ERR', err);
      }

   console.log(data);
   });
}

function sendTonightMovies() {
   var date = new Date();
   var year = date.getFullYear();
   var month = date.getMonth() + 1; // + 1, starting from 0;
   var day  = date.getDate();

   month = (month < 10 ? "0" : "") + month; // 1 becomes 01;
   day = (day < 10 ? "0" : "") + day;

   // sorteer can be 0 (all movies), 1 (filmtips) or 2 (movie of the day)
   var moviesUrl = 'http://api.filmtotaal.nl/filmsoptv.xml?apikey=l2qqhgafuem53h5ecrd4pd9wq2gtb2pp&dag=' + day + '-' + month + '-' + year + '&sorteer=0';
   let options = {
      uri: moviesUrl,
      xml: true
   };

   return rp(options)
      .then(function(xmlResult) {
         // Get movie descriptions:
         var messageToSend = "";
         parseString(xmlResult, function (err, JSONResult) {
            //console.dir(JSON.stringify(JSONResult));
            
            for (var i = 0; i < JSONResult.filmsoptv.film.length; i++) {
               var title = JSONResult.filmsoptv.film[i].titel;
               var unixTime = JSONResult.filmsoptv.film[i].starttijd;
               var date = new Date(unixTime*1000);
               var startTime = date.getHours() + ':' + date.getMinutes() + ' uur';
               var channel = JSONResult.filmsoptv.film[i].zender;
               var movieSummary = JSONResult.filmsoptv.film[i].synopsis;

               var movieDesc = `<h3>${title} speelt om ${startTime} op ${channel}.</h3>
                                 <p>Omschrijving:</p>
                                 <p>${movieSummary}</p>`;
               
               messageToSend += movieDesc;
            }
         });
         
         // Send email:
         var transporter = nodemailer.createTransport({
            service: 'hotmail',
            auth: {
               user: 'nabalexa123@hotmail.com',
               pass: 'Informatica4'
            }
         });
          
         var mailOptions = {
            from: 'nabalexa123@hotmail.com',
            to: 'nabalexa123@hotmail.com',
            subject: 'Films voor vanavond',
            html: messageToSend
         };
         
         transporter.sendMail(mailOptions, function(error, info){
            if (error) {
               console.log("Error: " + error);
            } else {
               console.log('Email sent: ' + info.response);
            }
         });

         return messageToSend; // is this required?
      });
}

async function getCurrentTemp() {
   var params = {
      QueueUrl: queueURL,
      MaxNumberOfMessages: 1
   };
   return await sqs.receiveMessage(params, async function(err, data) {
      //console.log("Data: " + JSON.stringify(data));
      var speech;
      if (err) {
         console.log("Receive error: ", err);
         callback(err, "Error fetching messages from SQS");
         speech = `The temperature is currently unavailable`;
      }
      else if (data.Messages) {
         //console.log("Number of messages received: " + data.Messages.length);
         //console.log("Received message: " + JSON.stringify(data.Messages[0]));
         
         var lastMessage = data.Messages[0].Body;
         console.log("Message body: " + lastMessage);

         if (lastMessage.startsWith("temp_", 0)) {
            lastMessage = '23';

            var deleteParams = {
               QueueUrl: queueURL,
               ReceiptHandle: data.Messages[0].ReceiptHandle
            }
            sqs.deleteMessage(deleteParams, function(err, data) {
               if (err)
                  console.log("Delete error: ", err);
               else 
                  console.log("Message deleted: ", data);
            })

            speech = `The current temperature is ${lastMessage}.`;
         }
         else {
            speech = `The temperature is currently unavailable`;
         }
      }
      else {
         console.log("No messages received");
         speech = `The temperature is currently unavailable`;
      }
      console.log('speech: ' + speech);
      return speech;
   });
   
   //return speech;
}